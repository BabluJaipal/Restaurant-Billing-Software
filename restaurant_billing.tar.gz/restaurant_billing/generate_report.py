
from fpdf import FPDF

class PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 15)
        self.cell(0, 10, 'Restaurant Billing Software - Project Report', 0, 1, 'C')
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    def chapter_title(self, title):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, title, 0, 1, 'L')
        self.ln(5)

    def chapter_body(self, body):
        self.set_font('Arial', '', 12)
        self.multi_cell(0, 10, body)
        self.ln()

def create_report():
    pdf = PDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    # Introduction
    pdf.chapter_title('Introduction')
    pdf.chapter_body('This report details the development of a Restaurant Billing Software, a Python-based application designed to streamline the billing process in a restaurant. The system provides a user-friendly interface for managing orders, calculating bills with GST, and generating sales reports. This project demonstrates the practical application of Python for building desktop applications with database integration.')

    # Abstract
    pdf.chapter_title('Abstract')
    pdf.chapter_body('The primary objective of this project is to create an efficient and easy-to-use billing system for restaurants. The software supports both dine-in and takeaway order types, manages a digital menu, and tracks all transactions. The system is built using Python, with Tkinter for the graphical user interface and SQLite for the database. The application also includes a reporting module to generate insights into sales and popular menu items.')

    # Tools Used
    pdf.chapter_title('Tools Used')
    pdf.chapter_body('- Python 3\n- Tkinter for GUI\n- SQLite3 for database management\n- pandas for data analysis and CSV report generation\n- FPDF for PDF report generation')

    # Steps Involved
    pdf.chapter_title('Steps Involved in Building the Project')
    steps = (
        "1. Requirement Analysis and Planning: The project started with a detailed analysis of the requirements, followed by planning the application architecture and database schema.\n"
        "2. Database Implementation: An SQLite database was created with tables for the menu, orders, and order items. The schema was designed to efficiently store and retrieve data related to billing and sales.\n"
        "3. User Interface Development: The graphical user interface was built using Tkinter, providing an intuitive and user-friendly experience for both admin and cashier roles.\n"
        "4. Core Logic and Functionality: The core business logic for order management, bill calculation (including GST and discounts), and payment processing was implemented in Python.\n"
        "5. Reporting Module: A reporting feature was developed to generate sales reports and analyze the most frequently sold items. This module uses the pandas library for data manipulation and export.\n"
        "6. Finalization and Testing: The application was thoroughly tested to ensure all features work correctly and handle edge cases gracefully. The code was then organized and documented to finalize the project."
    )
    pdf.chapter_body(steps)

    # Conclusion
    pdf.chapter_title('Conclusion')
    pdf.chapter_body('The Restaurant Billing Software project successfully delivers a complete and functional billing solution for restaurants. The use of Python and its rich ecosystem of libraries enabled the rapid development of a robust and scalable application. Future enhancements could include cloud integration, online ordering capabilities, and advanced analytics features to provide deeper insights into the business.')

    pdf.output('restaurant_billing/project_report.pdf')

if __name__ == '__main__':
    create_report()
