
from utils.db_utils import create_tables
from ui.main_ui import main
import pandas as pd
from utils.db_utils import get_db_connection

def seed_menu_data():
    """Seeds the menu data from a CSV file into the database."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if menu data already exists
    cursor.execute("SELECT COUNT(*) FROM menu")
    if cursor.fetchone()[0] > 0:
        conn.close()
        return

    menu_df = pd.read_csv("restaurant_billing/data/menu.csv")
    for _, row in menu_df.iterrows():
        cursor.execute("""
            INSERT INTO menu (name, category, price, gst)
            VALUES (?, ?, ?, ?)
        """, (row['name'], row['category'], row['price'], row['gst']))

    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_tables()
    seed_menu_data()
    main()
