
def calculate_bill(order_items, menu_dict, discount_percentage):
    """
    Calculates the subtotal, GST, discount, and total amount for an order.

    Args:
        order_items (dict): A dictionary with item names as keys and quantities as values.
        menu_dict (dict): A dictionary of menu items where keys are item names.
        discount_percentage (float): The discount percentage to apply.

    Returns:
        tuple: A tuple containing subtotal, gst_amount, discount_amount, and total_amount.
    """
    subtotal = 0
    gst_amount = 0

    for item_name, quantity in order_items.items():
        item = menu_dict[item_name]
        item_total = item['price'] * quantity
        subtotal += item_total
        gst_amount += item_total * item['gst']

    discount_amount = (subtotal * discount_percentage) / 100
    total_amount = subtotal + gst_amount - discount_amount

    return subtotal, gst_amount, discount_amount, total_amount
