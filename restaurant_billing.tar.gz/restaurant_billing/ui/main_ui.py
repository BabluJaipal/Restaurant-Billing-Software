
import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
from utils.db_utils import get_db_connection, create_tables
from utils.calculator import calculate_bill
import json
from datetime import datetime

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Restaurant Billing System")
        self.geometry("1200x800")

        self.conn = get_db_connection()
        self.menu_df = pd.read_sql_query("SELECT * FROM menu", self.conn)
        self.menu_dict = self.menu_df.set_index('name').to_dict('index')
        self.conn.close()

        self.order_items = {}

        self._create_widgets()

    def _create_widgets(self):
        # Main frames
        control_frame = ttk.Frame(self, padding="10")
        control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)

        bill_frame = ttk.Frame(self, padding="10")
        bill_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        # --- Control Frame Widgets ---
        ttk.Label(control_frame, text="Restaurant Billing", font=("Arial", 16, "bold")).pack(pady=10)

        # Order Type
        ttk.Label(control_frame, text="Order Type:").pack(anchor=tk.W, pady=5)
        self.order_type_var = tk.StringVar(value="Dine-In")
        ttk.Radiobutton(control_frame, text="Dine-In", variable=self.order_type_var, value="Dine-In").pack(anchor=tk.W)
        ttk.Radiobutton(control_frame, text="Takeaway", variable=self.order_type_var, value="Takeaway").pack(anchor=tk.W)

        # Add Items
        ttk.Label(control_frame, text="Add Item:", font=("Arial", 12, "bold")).pack(pady=(20, 5))
        self.item_var = tk.StringVar()
        item_menu = ttk.Combobox(control_frame, textvariable=self.item_var, values=self.menu_df['name'].tolist())
        item_menu.pack(fill=tk.X)
        item_menu.set("Select an item")

        ttk.Label(control_frame, text="Quantity:").pack(anchor=tk.W, pady=5)
        self.quantity_var = tk.IntVar(value=1)
        ttk.Spinbox(control_frame, from_=1, to=100, textvariable=self.quantity_var).pack(fill=tk.X)

        ttk.Button(control_frame, text="Add to Order", command=self.add_item).pack(fill=tk.X, pady=10)
        ttk.Button(control_frame, text="Remove from Order", command=self.remove_item).pack(fill=tk.X)
        
        # Payment
        ttk.Label(control_frame, text="Payment:", font=("Arial", 12, "bold")).pack(pady=(20, 5))
        self.payment_method_var = tk.StringVar(value="Cash")
        ttk.Combobox(control_frame, textvariable=self.payment_method_var, values=["Cash", "Card", "UPI"]).pack(fill=tk.X)

        ttk.Label(control_frame, text="Discount (%):").pack(anchor=tk.W, pady=5)
        self.discount_var = tk.DoubleVar(value=0)
        ttk.Spinbox(control_frame, from_=0, to=100, textvariable=self.discount_var).pack(fill=tk.X)

        ttk.Button(control_frame, text="Generate Bill", command=self.generate_bill, style="Accent.TButton").pack(fill=tk.X, pady=20)

        # --- Bill Frame Widgets ---
        ttk.Label(bill_frame, text="Current Order", font=("Arial", 14, "bold")).pack(pady=10)
        
        cols = ("Item", "Quantity", "Price", "Total")
        self.order_tree = ttk.Treeview(bill_frame, columns=cols, show='headings')
        for col in cols:
            self.order_tree.heading(col, text=col)
        self.order_tree.pack(fill=tk.BOTH, expand=True)

        self.bill_summary_label = ttk.Label(bill_frame, text="", font=("Arial", 12))
        self.bill_summary_label.pack(anchor=tk.E, pady=10)

        # Style
        style = ttk.Style(self)
        style.configure("Accent.TButton", font=("Arial", 12, "bold"), foreground="white", background="green")

    def add_item(self):
        item_name = self.item_var.get()
        if item_name not in self.menu_dict:
            messagebox.showerror("Error", "Please select a valid item.")
            return
        
        quantity = self.quantity_var.get()
        self.order_items[item_name] = self.order_items.get(item_name, 0) + quantity
        self.update_order_display()

    def remove_item(self):
        item_name = self.item_var.get()
        if item_name not in self.order_items:
            messagebox.showerror("Error", "Item not in order.")
            return
        
        quantity = self.quantity_var.get()
        self.order_items[item_name] -= quantity
        if self.order_items[item_name] <= 0:
            del self.order_items[item_name]
        self.update_order_display()

    def update_order_display(self):
        self.order_tree.delete(*self.order_tree.get_children())
        for item_name, quantity in self.order_items.items():
            price = self.menu_dict[item_name]['price']
            self.order_tree.insert("", tk.END, values=[item_name, quantity, f"{price:.2f}", f"{price * quantity:.2f}"])
        self.update_bill_summary()

    def update_bill_summary(self):
        if not self.order_items:
            self.bill_summary_label.config(text="")
            return
        
        subtotal, gst, discount, total = calculate_bill(self.order_items, self.menu_dict, self.discount_var.get())
        summary_text = (
            f"Subtotal: {subtotal:.2f}\n"
            f"GST: {gst:.2f}\n"
            f"Discount: -{discount:.2f}\n"
            f"--------------------\n"
            f"Total: {total:.2f}"
        )
        self.bill_summary_label.config(text=summary_text)

    def generate_bill(self):
        if not self.order_items:
            messagebox.showerror("Error", "Cannot generate a bill for an empty order.")
            return

        subtotal, gst, discount, total = calculate_bill(self.order_items, self.menu_dict, self.discount_var.get())
        
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO orders (order_type, payment_method, subtotal, gst_amount, discount, total_amount)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (self.order_type_var.get(), self.payment_method_var.get(), subtotal, gst, discount, total))
        order_id = cursor.lastrowid

        menu_id_map = self.menu_df.set_index('name')['id'].to_dict()
        for item_name, quantity in self.order_items.items():
            cursor.execute('''
                INSERT INTO order_items (order_id, menu_item_id, quantity)
                VALUES (?, ?, ?)
            ''', (order_id, menu_id_map[item_name], quantity))
        
        conn.commit()
        conn.close()
        self.generate_bill_files(order_id, total)

        messagebox.showinfo("Success", f"Bill #{order_id} generated successfully!")
        self.reset_app()

    def generate_bill_files(self, order_id, total):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_path = f"restaurant_billing/data/bill_{order_id}_{timestamp}"

        # JSON
        bill_data = {
            "order_id": order_id,
            "timestamp": datetime.now().isoformat(),
            "order_type": self.order_type_var.get(),
            "items": self.order_items,
            "total_amount": total
        }
        with open(f"{base_path}.json", 'w') as f:
            json.dump(bill_data, f, indent=4)
        
        # CSV
        order_df = pd.DataFrame(self.order_items.items(), columns=['Item', 'Quantity'])
        order_df.to_csv(f"{base_path}.csv", index=False)


    def reset_app(self):
        self.order_items = {}
        self.quantity_var.set(1)
        self.discount_var.set(0)
        self.item_var.set("Select an item")
        self.update_order_display()

def main():
    create_tables()
    app = App()
    app.mainloop()
